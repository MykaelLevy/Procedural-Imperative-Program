def old_users():
  usuarios = []
  usuarios.append({'nome': 'João', 'id': '1', 'pontos_de_rank': [56, 78, 43]})
  usuarios.append({'nome': 'Maria', 'id': '2', 'pontos_de_rank': [32, 21, 47]})
  usuarios.append({'nome': 'Pedro', 'id': '3', 'pontos_de_rank': [76, 32, 56]})
  return usuarios

def cadastrar_usuario(usuarios, nome, id_usuario):
  usuario = {'nome': nome, 'id': id_usuario, 'pontos_de_rank': []}
  usuarios.append(usuario)

usuarios = old_users()

def listar():
  if usuarios:
      print("\n[#] Lista de usuários:")
      for usuario in usuarios:
          print(f"\n[#] ID: {usuario['id']}, Usuário: {usuario['nome']}, Pontos de Rank: {usuario['pontos_de_rank']}")
  else:
      print("\n[#] A lista de usuários está vazia.")

def calcular_media_individual():
  for usuario in usuarios:
      if usuario['pontos_de_rank']:
          media_individual = sum(usuario['pontos_de_rank']) / len(usuario['pontos_de_rank'])
          print(f"\n[#] A média do usuário {usuario['nome']} é: {media_individual}")
      else:
          print(f"\n[#] O usuário {usuario['nome']} ainda não possui pontos de rank.")

def calcular_media_geral_e_ranking():
  if usuarios:
      todos_pontos = [ponto for usuario in usuarios for ponto in usuario['pontos_de_rank']]
      media_geral = sum(todos_pontos) / len(todos_pontos)
      print(f"\n[#] A média geral dos usuários é: {media_geral}")

      ranking = sorted(usuarios, key=lambda x: sum(x['pontos_de_rank']) / len(x['pontos_de_rank']) if x['pontos_de_rank'] else 0, reverse=True)
      print("\n[#] Ranking dos usuários:")
      for i, usuario in enumerate(ranking, 1):
          print(f"{i}. {usuario['nome']} - Média: {sum(usuario['pontos_de_rank']) / len(usuario['pontos_de_rank']) if usuario['pontos_de_rank'] else 'Sem dados'}")
  else:
      print("\n[#] Não há usuários cadastrados.")

def adicionar_ponto_de_rank():
  id_usuario = input("\n[#] Digite o ID do usuário para adicionar ponto de rank: ")
  for usuario in usuarios:
      if usuario['id'] == id_usuario:
          pontos = []
          for _ in range(3):
              ponto = int(input(f"\n[#] Digite o ponto de rank {_ + 1}: "))
              pontos.append(ponto)
          usuario['pontos_de_rank'].extend(pontos)
          print(f"\n[#] Pontos {pontos} adicionados ao usuário {usuario['nome']}.")
          return
  print("\n[#] Usuário não encontrado.")

def cadastrar():
  nome = input("\n[#] Digite o nome do usuário: ")
  id_usuario = input("\n[#] Digite o ID do usuário: ")
  cadastrar_usuario(usuarios, nome, id_usuario)
  print(f"\n[#] Usuário {nome} cadastrado com sucesso.")

def excluir_usuario():
  id_usuario = input("[#] Digite o ID do usuário que deseja excluir: ")
  for usuario in usuarios:
      if usuario['id'] == id_usuario:
          usuarios.remove(usuario)
          print(f"\n[#] O usuário {usuario['nome']} foi excluído.")
          return
  print("\n[#] Usuário não encontrado.")

def buscar_usuario():
  id_usuario = input("[#] Digite o ID do usuário que deseja buscar: ")
  for usuario in usuarios:
      if usuario['id'] == id_usuario:
          print(f"\n[#] Usuário encontrado: {usuario['nome']} - Pontos de Rank: {usuario['pontos_de_rank']}")
          return
  print("\n[#] Usuário não encontrado.")

def info():
  print("[!]O calculo se da pela seguinte forma: \n")
  print("\n[!]Cada jogador terá que jogar uma melhor de 3 partidas,\nao final de cada partida o jogador terá\nque cadastrar seus respectivos 3 pontos de ranking.")
  print("\n[!]A média de cada jogador será atribuida no ranking.")