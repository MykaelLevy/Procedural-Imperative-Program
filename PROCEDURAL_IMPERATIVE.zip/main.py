import funcoes

while True:
  print("________________________________\n|[#] Menu:")
  print("|[1] Listar\n|[2] Cadastrar usuário\n|[3] Adicionar ponto de rank\n|[4] Excluir usuário\n|[5] Buscar usuário\n|[6] Calcular média individual\n|[7] Calcular média geral e ranking\n|[!] INFO\n|[0] Sair")
  print("--------------------------------")

  opcao = input("\n[#] Escolha uma opção:")
  print("--------------------------------")
      
  if opcao == '1':
    funcoes.listar()
  elif opcao == '2':
    funcoes.cadastrar()
  elif opcao == '3':
    funcoes.adicionar_ponto_de_rank()
  elif opcao == '4':
    funcoes.excluir_usuario()
  elif opcao == '5':
    funcoes.buscar_usuario()
  elif opcao == '6':
    funcoes.calcular_media_individual()
  elif opcao == '7':
    funcoes.calcular_media_geral_e_ranking()
  elif opcao == '!':
    funcoes.info()
  elif opcao == '0':
    print("Saindo do programa...")
    break
  else:
        print("Opção inválida. Por favor, escolha uma opção válida.")
